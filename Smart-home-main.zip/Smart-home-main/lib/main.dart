import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:untitled55/UI/pages/RoomsPage.dart';
import 'package:untitled55/theme.dart';
import 'UI/pages/login_page.dart';

void main() async {

  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  final SharedPreferences prefs = await SharedPreferences.getInstance();
  bool login = prefs.getBool("isLogged") ?? false;
  runApp(MyApp(check: login));
}

class MyApp extends StatelessWidget {
  final bool check;
  const MyApp({super.key, required this.check});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(

      debugShowCheckedModeBanner: true,
      theme: AppTheme.darkTheme,
      home: check ?RoomsPage() :LoginScreen() ,
    );
  }
}
